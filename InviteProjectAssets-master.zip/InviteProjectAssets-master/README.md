# InviteProjectAssets
Privacy Policy 
  -[Visit](https://sameer-shahzada.github.io/InviteProjectAssets/invitePrivacy.html)
